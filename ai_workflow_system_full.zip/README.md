
# AI Workflow System

Modular AI Orchestrator + RAG experimentation project.
Run with: python main.py
