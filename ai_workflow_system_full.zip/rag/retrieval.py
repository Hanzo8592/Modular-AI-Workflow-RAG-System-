
def multi_retrieve(subquestions):
    results = []
    for q in subquestions:
        results.append(f"Dummy evidence for {q}")
    return results
